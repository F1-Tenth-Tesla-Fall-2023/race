# Assignment 2
Code that contains our PID wall following and completed skelton code of the race package.

## Set-up
Clone this repository into our catkin workspace.
